
public class TEST {

	public static void main(String[] args) {
		String s = "Omar Salman Alqarni";
		String demarcation = " ";
		String[] list = new String[10];
		int start = 0, end = s.indexOf(demarcation, start);
		int counter = 0;
		while (end != -1) {
			String parts = s.substring(start, end);
			list[counter++] = parts;
			
			start = end +1;
			end = s.indexOf(demarcation, start);
		}
		String parts = s.substring(start);
		list[counter++] = parts;

		
		
		
		for(int i=0; i<counter ; i++) {
			System.out.print(list[i]);
		}
	}

}
