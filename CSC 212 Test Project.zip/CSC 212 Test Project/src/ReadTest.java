import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ReadTest {
	

	public static void main(String[] args) throws FileNotFoundException {
		File file = new File("C:\\Users\\Omara\\OneDrive\\Desktop\\SEM 461\\CSC 212\\data\\dataset.CSV");
		
		try {
			Scanner scan = new Scanner(file);
			while(scan.hasNextLine()) {
				String s = scan.nextLine();
				s = prepair(s);
				System.out.println(s);
			}
		}catch(Exception e) {
			
		}

	}
	
	public static String prepair(String s) {
		int id;
		int index = s.indexOf(",");
		if ( isInteger(s.substring(0, index))) {
			id = Integer.parseInt(s.substring(0, index));
			s = s.substring(index+1);
			System.out.print(id+": ");
		}
		else {
			return "";
		}
		String prepair = "";
		for(int i =0 ; i<s.length();i++) {
			if(!isPunctionOrNonAlphanumerical(s.charAt(i)))
				prepair = prepair + s.charAt(i);
		}
		prepair = prepair.toLowerCase();
		prepair = removeStopWords(prepair);
		return prepair;
		
		
	}
	
	public static boolean isInteger(String str) {
        return str != null && str.matches("-?\\d+");
    }
	
	public static boolean isPunctionOrNonAlphanumerical(char c) {
		char [] punctuations = {'.', ',', '?', '!', ':', ';', '\'', '"', '—', '(', ')', '[', ']', '.', '.', '.', '/', '{', '}',
				'.', ',', '?', '!', ':', ';', '\'', '"', '-', '—', '(', ')', '[', ']', '{', '}', '<', '>', '/', '\\', '|', '@',
				'#', '$', '%', '^', '&', '*', '_', '+', '=', '~', '`'};// -
		for (int i = 0; i< punctuations.length; i++) {
			if(c == punctuations[i])
				return true;
		}
		return false;
	}
	
	public static String removeStopWords(String s) {
		String demarcation = " ";
		String noStopWords = "";
		int start = 0, end = s.indexOf(demarcation, start);
		int counter = 0;
		while(end != -1) {
			String parts = s.substring(start, end);
			if(!isStopWord(parts))
				noStopWords = noStopWords + parts +" ";
			start = end +1;
			end = s.indexOf(demarcation, start);
		}
		String parts = s.substring(start);
		if(!isStopWord(parts))
			noStopWords = noStopWords + parts +" ";
		return noStopWords;
		
	}
	
	public static boolean isStopWord(String s) {
		String[] stopWords = {"a", "a's", "able", "about", "above", "according", "accordingly", "across", "actually", "after", 
	            "afterwards", "again", "against", "ain't", "all", "allow", "allows", "almost", "alone", "along", 
	            "already", "also", "although", "always", "am", "among", "amongst", "an", "and", "another", 
	            "any", "anybody", "anyhow", "anyone", "anything", "anyway", "anyways", "anywhere", "apart", 
	            "appear", "appreciate", "appropriate", "are", "aren't", "around", "as", "aside", "ask", "asking", 
	            "associated", "at", "available", "away", "awfully", "b", "be", "became", "because", "become", 
	            "becomes", "becoming", "been", "before", "beforehand", "behind", "being", "believe", "below", 
	            "beside", "besides", "best", "better", "between", "beyond", "both", "brief", "but", "by", "c", 
	            "c'mon", "c's", "came", "can", "can't", "cannot", "cant", "cause", "causes", "certain", 
	            "certainly", "changes", "clearly", "co", "com", "come", "comes", "concerning", "consequently", 
	            "consider", "considering", "contain", "containing", "contains", "corresponding", "could", 
	            "couldn't", "course", "currently", "d", "definitely", "described", "despite", "did", "didn't", 
	            "different", "do", "does", "doesn't", "doing", "don't", "done", "down", "downwards", "during", 
	            "e", "each", "edu", "eg", "eight", "either", "else", "elsewhere", "enough", "entirely", 
	            "especially", "et", "etc", "even", "ever", "every", "everybody", "everyone", "everything", 
	            "everywhere", "ex", "exactly", "example", "except", "f", "far", "few", "fifth", "first", "five", 
	            "followed", "following", "follows", "for", "former", "formerly", "forth", "four", "from", 
	            "further", "furthermore", "g", "get", "gets", "getting", "given", "gives", "go", "goes", 
	            "going", "gone", "got", "gotten", "greetings", "h", "had", "hadn't", "happens", "hardly", 
	            "has", "hasn't", "have", "haven't", "having", "he", "he's", "hello", "help", "hence", "her", 
	            "here", "here's", "hereafter", "hereby", "herein", "hereupon", "hers", "herself", "hi", "him", 
	            "himself", "his", "hither", "hopefully", "how", "howbeit", "however", "i", "i'd", "i'll", "i'm", 
	            "i've", "ie", "if", "ignored", "immediate", "in", "inasmuch", "inc", "indeed", "indicate", 
	            "indicated", "indicates", "inner", "insofar", "instead", "into", "inward", "is", "isn't", "it", 
	            "it'd", "it'll", "it's", "its", "itself", "j", "just", "k", "keep", "keeps", "kept", "know", 
	            "knows", "known", "l", "last", "lately", "later", "latter", "latterly", "least", "less", "lest", 
	            "let", "let's", "like", "liked", "likely", "little", "look", "looking", "looks", "ltd", "m", 
	            "mainly", "many", "may", "maybe", "me", "mean", "meanwhile", "merely", "might", "more", 
	            "moreover", "most", "mostly", "much", "must", "my", "myself", "n", "name", "namely", "nd", 
	            "near", "nearly", "necessary", "need", "needs", "neither", "never", "nevertheless", "new", 
	            "next", "nine", "no", "nobody", "non", "none", "noone", "nor", "normally", "not", "nothing", 
	            "novel", "now", "nowhere", "o", "obviously", "of", "off", "often", "oh", "ok", "okay", "old", 
	            "on", "once", "one", "ones", "only", "onto", "or", "other", "others", "otherwise", "ought", 
	            "our", "ours", "ourselves", "out", "outside", "over", "overall", "own", "p", "particular", 
	            "particularly", "per", "perhaps", "placed", "please", "plus", "possible", "presumably", 
	            "probably", "provides", "q", "que", "quite", "qv", "r", "rather", "rd", "re", "really", 
	            "reasonably", "regarding", "regardless", "regards", "relatively", "respectively", "right", 
	            "s", "said", "same", "saw", "say", "saying", "says", "second", "secondly", "see", "seeing", 
	            "seem", "seemed", "seeming", "seems", "seen", "self", "selves", "sensible", "sent", "serious", 
	            "seriously", "seven", "several", "shall", "she", "should", "shouldn't", "since", "six", "so", 
	            "some", "somebody", "somehow", "someone", "something", "sometime", "sometimes", "somewhat", 
	            "somewhere", "soon", "sorry", "specified", "specify", "specifying", "still", "sub", "such", 
	            "sup", "sure", "t", "t's", "take", "taken", "tell", "tends", "th", "than", "thank", "thanks", 
	            "thanx", "that", "that's", "thats", "the", "their", "theirs", "them", "themselves", "then", 
	            "thence", "there", "there's", "thereafter", "thereby", "therefore", "therein", "theres", 
	            "thereupon", "these", "they", "they'd", "they'll", "they're", "they've", "think", "third", 
	            "this", "thorough", "thoroughly", "those", "though", "three", "through", "throughout", "thru", 
	            "thus", "to", "together", "too", "took", "toward", "towards", "tried", "tries", "truly", "try", 
	            "trying", "twice", "two", "u", "un", "under", "unfortunately", "unless", "unlikely", "until", 
	            "unto", "up", "upon", "us", "use", "used", "useful", "uses", "using", "usually", "uucp", "v", 
	            "value", "various", "very", "via", "viz", "vs", "w", "want", "wants", "was", "wasn't", "way", 
	            "we", "we'd", "we'll", "we're", "we've", "welcome", "well", "went", "were", "weren't", "what", 
	            "what's", "whatever", "when", "whence", "whenever", "where", "where's", "whereafter", "whereas", 
	            "whereby", "wherein", "whereupon", "wherever", "whether", "which", "while", "whither", "who", 
	            "who's", "whoever", "whole", "whom", "whose", "why", "will", "willing", "wish", "with", "within", 
	            "without", "won't", "wonder", "would", "would", "wouldn't", "x", "y", "yes", "yet", "you", "you'd",
	            "you'll", "you're", "you've", "your", "yours", "yourself", "yourselves", "z", "zero"};
		for (int i=0; i<stopWords.length;i++) {
			if(s.equals(stopWords[i]))
				return true;
		}
		return false;
	}

}
