
public class invertedIndex {
	LinkedList<Integer> IDofDocuments = new LinkedList<Integer>();
	String word;
	
	public invertedIndex() {
		
	}
	
	public void add(String word, LinkedList<Index> index) {
		this.word = word;
		index.findFirst();
		while(!index.last()) {
			if(index.retrieve().exist(word)) {
				IDofDocuments.insert(index.retrieve().id);
			}
			index.findNext();
		}
		if(index.retrieve().exist(word)) {
			IDofDocuments.insert(index.retrieve().id);
		}
	}
}
