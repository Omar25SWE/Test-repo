
public class Queries {
	SearchEngine engine = new SearchEngine();
	LinkedList<String> query = new LinkedList<String>();
	LinkedList<Integer> result = new LinkedList<Integer>();
	
	public void QueryProcessing(String s) {
		String demarcation = " ";
		int start = 0, end = s.indexOf(demarcation, start);
		while(end != -1) {
			String parts = s.substring(start, end);
			query.insert(parts);
			
			start = end +1;
			end = s.indexOf(demarcation, start);
		}
		String parts = s.substring(start);
		query.insert(parts);
		
		
	}
	
	public void AND() {
		
	}
	
	public void OR() {
		
	}
	
	public void ANDOR() {
		
	}

}
