
public class TestMain {

	public static void main(String[] args) {
		LinkedList<String> lines = new LinkedList<String>();
		LinkedList<LinkedList> list = new LinkedList<LinkedList>();
		String a = "Omar Salman Alqarni";
		String b = "Ahmed Yahya AL-Asmri";
		lines.insert(a);
		lines.insert(b);
		lines.findFirst();
		
		String demarcation = " ";
		
		for(int i =0 ; i < lines.size() ; i++) {
			LinkedList<String> words = new LinkedList<String>();
			int start = 0, end = lines.retrieve().indexOf(demarcation, start);
			int counter = 0;
			while(end != -1) {
				String parts = lines.retrieve().substring(start, end);
				words.insert(parts);
				
				start = end +1;
				end = lines.retrieve().indexOf(demarcation, start);
			}
			String parts = lines.retrieve().substring(start);
			words.insert(parts);
			
			list.insert(words);
			
			lines.findNext();
		}
		
		int k =list.size();
		list.findFirst();
		for(int i = 0 ; i< k ; i++) {
			list.retrieve().print();
			list.findNext();
		}

	}

}
